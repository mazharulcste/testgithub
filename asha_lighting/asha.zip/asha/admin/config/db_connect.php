<?php
@session_start();
$connection=mysql_connect('localhost','root','');
mysql_select_db("admin_template",$connection);
?>