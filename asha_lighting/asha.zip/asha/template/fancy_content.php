
<div class="gallery">
    <div class="container">
        <div class="gallery-top heading">
            <h2> Fancy Bracket & Table Lamp Gallery</h2>
        </div>
        <div class="gallery-bottom">
            <div class="gallery-grids">
                <div class="col-md-4 gallery-left">
                    <div class="g-1">	
                        <a href="product_details.php"> <img style="padding: 20px;"  src="images/spot_1.jpg" alt=""/> </a>						
                    </div>

                </div>
                
                <div class="col-md-4 gallery-left">
                    <div class="g-1">	
                        <a href="product_details.php"> <img  style="padding: 20px;" src="images/spot_1.jpg" alt=""/> </a>						
                    </div>
                </div>
                
                <div class="col-md-4 gallery-left">
                    <div class="g-1">	
                        <a href="product_details.php"> <img style="padding: 20px;"  src="images/spot_1.jpg" alt=""/> </a>						
                    </div>

                </div>
                
                <div class="clearfix"> </div>					
            </div>
        </div>
    </div>
</div>