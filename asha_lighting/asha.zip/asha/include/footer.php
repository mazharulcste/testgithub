	<div class="footer">
		<div class="container text-center">
			<div class="footer-top">
				
				<div class="col-md-12 footer-right">
					<p>Copyright 2015. All rights reserved | Developed by <a href="http://www.bsdbd.com">Bangladesh Software Development(BSD)</a></p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<script type="text/javascript">
									$(document).ready(function() {
										/*
										var defaults = {
								  			containerID: 'toTop', // fading element id
											containerHoverID: 'toTopHover', // fading element hover id
											scrollSpeed: 1200,
											easingType: 'linear' 
								 		};
										*/
										
										$().UItoTop({ easingType: 'easeOutQuart' });
										
									});
								</script>
		<a href="#home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	</div>