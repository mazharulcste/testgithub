<?php
@session_start();
$connection=mysql_connect('localhost','ashaligh_admin','100300');
mysql_select_db("ashaligh_asha",$connection);
?>