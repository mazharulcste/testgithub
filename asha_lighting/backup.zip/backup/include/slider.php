
<iframe src="asha slider/index.php" style="width:100%;height:360px;max-width:100%;overflow:hidden;border:none;padding:0;margin:0 auto;display:block;" scrolling="no" marginheight="0" marginwidth="0"></iframe>




<!--<div class="banner" style="margin-top: 20px;">
    <section class="slider">
        <div class="flexslider">
            <ul class="slides">
                <li>
                    <div class="banner12">
                        <div class="container">
                            <img src="asha image/slider_1.jpg">
                        </div>
                    </div>
                </li>
                <li>
                    <div class="banner21">
                        <div class="container">
                            <img src="asha image/slider_2.jpg">
                        </div>
                    </div>
                </li>
                <li>
                    <div class="banner12">
                        <div class="container">
                            <img src="asha image/slider_3.jpg">
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </section>
</div>-->

