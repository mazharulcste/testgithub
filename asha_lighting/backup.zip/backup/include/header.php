<!--header-top-->
<div class="header-top" id="home" style="background-image: url('images/header_1.jpg')">
		<div class="container">
			<div class="head-main">
				
                            <div class="col-md-12 head-middle">
                                <h1><a href="index.php"> <b style="color:#000;">Asha Lighting </b></a></h1>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
	<!--header-top-->
	<!--search-scripts-->
	<script src="js/classie.js"></script>
	<script src="js/uisearch.js"></script>
		<script>
			new UISearch( document.getElementById( 'sb-search' ) );
		</script>
	<!--//search-scripts-->