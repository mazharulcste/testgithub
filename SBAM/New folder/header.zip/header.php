<!--
Au<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>South Bangla</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Super Bikes  Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,800italic,800,700italic,700,600italic,600,400italic,300italic,300' rel='stylesheet' type='text/css'>
<script src="js/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />

<script src="js/responsiveslides.min.js"></script>
<script>
    $(function () {
      $("#slider").responsiveSlides({
      	auto: true,
      	nav: true,
      	speed: 500,
        namespace: "callbacks",
        pager: true,
      });
    });
	
  </script>
  <script src="js/bootstrap.js"></script>

</head>
<body style="max-width:1100px;margin:auto;">
		<!--start-header-section-->

	<div class="header">
	
		<div class="container">
			
	   <div style="height:170px;background-color:white;">
		  <img src="images/logo3.png" class="img-fluid" alt="Responsive image" style="width:140px;float:left;">
	      <img src="images/southbangla3.png" class="img-fluid" alt="Responsive image" style="margin-left:0px;width:500px;margin-top:100px;">
	  	</div>
	
		 
	<div class="container">
		<div class="">
				<nav class="navbar navbar-default">
					<div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div>
        <!-- Collect the nav links, forms, and other content for toggling -->
						<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1"style="background-color:gray;width:1070px;margin-left:-31px;margin-top:-5px;">
						  <ul class="nav navbar-nav cl-effect-16" >
							<li class="active"><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
							<li><a href="about.php">About</a></li>
							
							 <li class="dropdown">
							  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Product<span class="caret"></span></a>
							  <ul class="dropdown-menu">
								 
								<li><a href="new_car.php">New Car</a></li>
								<li><a href="re-condition_car.php">Re Condition Car</a></li>
								<li><a href="accessories.php">Accessories</a></li>
								
							  </ul>
							</li>
								<li><a href="gallery.php">Gallery</a></li>
								<li><a href="services.php">Services</a></li>
								<li><a href="contact.php">Contact</a></li>
						  </ul>
						</div><!-- /.navbar-collapse -->
					</div><!-- /.container-fluid -->
				</nav>
			</div>
</div>
